# coding: utf-8
import os


DEBUG = False
SECRET_KEY = 'JQSd^coU91KT2NcT!O5RgP&q5a&aZ62y'
MD5_SALT = 'hjabkjajoi'

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
MEDIA_ROOT = os.path.join(PROJECT_ROOT, 'media')
