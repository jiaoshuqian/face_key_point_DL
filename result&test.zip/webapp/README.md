WebApp
======

This project use flask to handle the requests and with Caffe CNNs to predict facial landmark.

All codes are written in Python.
